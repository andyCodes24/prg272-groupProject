﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using prg272_groupProject.PresentationLayer;


namespace prg272_groupProject.Presentation_Layer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // public Form1()
        // {
        //     InitializeComponent();
        //    dataGridViewHeroes.Visible = false; // hide it at startup
        //}

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (!int.TryParse(textBox1.Text, out int value1))
            {
                MessageBox.Show("HeroID must be a number.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox1.Focus();
                return;
            }

            if (!int.TryParse(textBox2.Text, out int value2))
            {
                MessageBox.Show(" Age must be a number.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox2.Focus();
                return;
            }

            string value3 = textBox3.Text.Trim();
            string value4 = textBox4.Text.Trim();

            if (string.IsNullOrWhiteSpace(value3))
            {
                MessageBox.Show("Cannot be empty.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox3.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(value4))
            {
                MessageBox.Show("Cannot be empty.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox4.Focus();
                return;
            }

            string filePath = @"C:\Users\Andile\Downloads\PRG272-GROUP PROJECT\prg272-groupProject\DataLayer\Superheroes.txt";


            try
            {
                string line = $"{value1}, {value2}, {value3}, {value4}{Environment.NewLine}";
                File.AppendAllText(filePath, line);

                MessageBox.Show("Input saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
            }
            catch (IOException ex)
            {
                MessageBox.Show($"Error saving data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox1.Text) && !int.TryParse(textBox1.Text, out _))
            {
                errorProvider1.SetError(textBox1, "HeroID must be a number!");
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox2.Text) && !int.TryParse(textBox2.Text, out _))
            {
                errorProvider1.SetError(textBox2, "Age must be a number!");
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox3.Text))
            {
                errorProvider1.SetError(textBox3, "Cannot be empty!");
            }
            else if (textBox3.Text.Any(char.IsDigit))
            {
                errorProvider1.SetError(textBox3, "Numbers are not allowed!");
            }
            else
            {
                errorProvider1.Clear();
            }

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox3.Text))
            {
                errorProvider1.SetError(textBox3, "Cannot be empty!");
            }
            else if (textBox3.Text.Any(char.IsDigit))
            {
                errorProvider1.SetError(textBox3, "Numbers are not allowed!");
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DataGridViewscs viewForm = new DataGridViewscs();
            viewForm.ShowDialog();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            int score = 0; // declare score outside so it's in scope

            if (string.IsNullOrWhiteSpace(textBox6.Text))
            {
                errorProvider1.SetError(textBox6, "Cannot be empty!");
            }
            else if (!int.TryParse(textBox6.Text, out score)) // <-- use textBox6 here, not textBox5
            {
                errorProvider1.SetError(textBox6, "Enter a valid number!");
            }
            else if (score < 0 || score > 100)
            {
                errorProvider1.SetError(textBox6, "Score must be between 0 and 100!");
            }
            else
            {
                errorProvider1.Clear();
            }

            // Now score is in scope, so you can calculate rank
            string rank = "";
            if (score >= 81) rank = "S";
            else if (score >= 61) rank = "A";
            else if (score >= 41) rank = "B";
            else rank = "C";
        }
        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            string heroID = textBox1.Text.Trim();
            string age = textBox2.Text.Trim();
            string name = textBox3.Text.Trim();
            string superpower = textBox4.Text.Trim();


            if (string.IsNullOrWhiteSpace(heroID) || string.IsNullOrWhiteSpace(age) ||
                string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(superpower))
            {
                MessageBox.Show("Please fill in all fields.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(heroID, out _) || !int.TryParse(age, out _))
            {
                MessageBox.Show("HeroID and Age must be numbers.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }


            string filePath = @"C:\Users\Andile\Downloads\PRG272-GROUP PROJECT\prg272-groupProject\DataLayer\Superheroes.txt";


            if (!File.Exists(filePath))
                File.WriteAllText(filePath, "");

            var lines = File.ReadAllLines(filePath).ToList();
            int index = lines.FindIndex(l => l.StartsWith(heroID + ","));

            if (index >= 0)
            {

                lines[index] = $"{heroID},{age},{name},{superpower}";
                MessageBox.Show("Hero updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {

                lines.Add($"{heroID},{age},{name},{superpower}");
                MessageBox.Show("Hero added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


            File.WriteAllLines(filePath, lines);


            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();


        }

        private void button4_Click(object sender, EventArgs e)
        {
            string filePath = @"C:\Users\Andile\Downloads\PRG272-GROUP PROJECT\prg272-groupProject\DataLayer\Superheroes.txt";
            if (!File.Exists(filePath))
            {
                MessageBox.Show("No superhero data found.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var lines = File.ReadAllLines(filePath);
            if (lines.Length == 0)
            {
                MessageBox.Show("No superhero data in the file.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int totalHeroes = 0;
            double totalAge = 0;
            double totalScore = 0;
            int sCount = 0, aCount = 0, bCount = 0, cCount = 0;

            foreach (var line in lines)
            {
                if (string.IsNullOrWhiteSpace(line)) continue;

                string[] parts = line.Split(',');
                if (parts.Length < 4) continue;

                totalHeroes++;

                int age = int.Parse(parts[1].Trim());
                int score = int.Parse(parts[4].Trim());

                string rank = "";
                if (score >= 81) rank = "S";
                else if (score >= 61) rank = "A";
                else if (score >= 41) rank = "B";
                else rank = "C";

                switch (rank)
                {
                    case "S": sCount++; break;
                    case "A": aCount++; break;
                    case "B": bCount++; break;
                    case "C": cCount++; break;
                }

                totalAge += age;
                totalScore += score;
            }

            double avgAge = totalAge / totalHeroes;
            double avgScore = totalScore / totalHeroes;

            string summary = $"Superhero Summary Report\n";
            summary += "========================\n";
            summary += $"Total Superheroes: {totalHeroes}\n";
            summary += $"Average Age: {avgAge:F1}\n";
            summary += $"Average Exam Score: {avgScore:F1}\n";
            summary += "\nCount per Rank:\n";
            summary += $"S-Rank: {sCount}\n";
            summary += $"A-Rank: {aCount}\n";
            summary += $"B-Rank: {bCount}\n";
            summary += $"C-Rank: {cCount}\n";

            string summaryFile = @"C:\Users\Andile\Downloads\PRG272-GROUP PROJECT\prg272-groupProject\DataLayer\summary.txt";

            try
            {
                File.WriteAllText(summaryFile, summary);
                MessageBox.Show("Summary report generated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving summary: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}