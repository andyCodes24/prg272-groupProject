﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prg272_groupProject.PresentationLayer
{
    public partial class DataGridViewscs : Form
    {
        public DataGridViewscs()
        {
            InitializeComponent();
        }

        private void DataGridViewscs_Load(object sender, EventArgs e)
        {
            LoadHeroData();
        }
        private void LoadHeroData()
        {
            string filePath = @"C:\Users\Andile\Downloads\PRG272-GROUP PROJECT\prg272-groupProject\DataLayer\Superheroes.txt";

            if (File.Exists(filePath))
            {
                var lines = File.ReadAllLines(filePath);

                DataTable dt = new DataTable();
                dt.Columns.Add("Hero ID");
                dt.Columns.Add("Age");
                dt.Columns.Add("Name");
                dt.Columns.Add("SuperPower");
                dt.Columns.Add("Exam Score");
                dt.Columns.Add("Rank");

                foreach (string line in lines)
                {
                    if (!string.IsNullOrWhiteSpace(line))
                    {
                        string[] parts = line.Split(',');
                        if (parts.Length >= 6) 
                        {
                            dt.Rows.Add(
                                parts[0].Trim(),  
                                parts[1].Trim(),  
                                parts[2].Trim(),  
                                parts[3].Trim(),  
                                parts[4].Trim(),  
                                parts[5].Trim()   
                            );
                        }
                    }
                }

                dataGridView1.DataSource = dt;
            }
            else
            {
                MessageBox.Show("No saved heroes found yet.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a hero to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            
            string heroID = dataGridView1.SelectedRows[0].Cells["Hero ID"].Value.ToString();

            string filePath = @"C:\Users\Andile\Downloads\PRG272-GROUP PROJECT\prg272-groupProject\DataLayer\Superheroes.txt";

            if (!File.Exists(filePath))
            {
                MessageBox.Show("Superhero file not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            
            var lines = File.ReadAllLines(filePath).ToList();

            
            int index = lines.FindIndex(l => l.StartsWith(heroID + ","));
            if (index >= 0)
            {
                
                var confirm = MessageBox.Show("Are you sure you want to delete this hero?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirm == DialogResult.Yes)
                {
                    
                    lines.RemoveAt(index);
                    File.WriteAllLines(filePath, lines);

                    MessageBox.Show("Hero deleted successfully!", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    
                    LoadHeroData();
                }
            }
            else
            {
                MessageBox.Show("Hero ID not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}
